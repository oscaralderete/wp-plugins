/*!
Developed by Web+apps Para Emprendedores
@author: Oscar Alderete <oscaralderete@gmail.com>
@website: https://wpe.oscaralderete.com
*/
const MarkersOnOpenStreetMap = Vue.createApp({
	data() {
		return {
			key: openstreetmapData.key,
			markers: openstreetmapData.markers,
			marker: this.getBlankMarker(),
			map_height: openstreetmapData.map_height,
			edited_marker: this.getBlankMarker(),
			edited_index: null,
			initial_zoom: openstreetmapData.initial_zoom,
			marker_start_color: openstreetmapData.marker_start_color,
			marker_end_color: openstreetmapData.marker_end_color,
			wpe_email: openstreetmapData.wpe_email,
			loader: document.querySelector('oa-loader'),
			dialog: document.querySelector('oa-dialogs'),
			toast: document.querySelector('oa-toast'),
		};
	},
	mounted() {
		const a = document.getElementById('contact_wpe');
		a.href = `mailto:${this.wpe_email}`;
		a.innerText = this.wpe_email;
	},
	methods: {
		getBlankMarker() {
			return {
				title: '',
				content: '',
				latitude: null,
				longitude: null
			}
		},
		updateZoomLevel() {
			const self = this;
			if (this.initial_zoom == '') {
				this.dialog.show({
					title: 'ERROR',
					message: 'Debes ingresar un zoom válido.',
				});
				return false;
			}
			this.loader.show();
			this.fetch({
				type: 'save_initial_zoom',
				data: {
					initial_zoom: self.initial_zoom,
				}
			}, function (response) {
				self.loader.hide();
				self.initial_zoom = response.initial_zoom;
				self.toast.success(response.msg);
			});
		},
		updateMapHeight() {
			const self = this;
			if (this.map_height <= 0) {
				this.dialog.show({
					title: 'ERROR',
					message: 'Debes ingresar una altura válida.',
				});
				return false;
			}
			this.loader.show();
			this.fetch({
				type: 'save_map_height',
				data: {
					map_height: self.map_height,
				}
			}, function (response) {
				self.loader.hide();
				self.toast.success(response.msg);
			});
		},
		saveMarker() {
			const self = this;
			this.markers.push(this.marker);
			this.loader.show();
			this.fetch({
				type: 'save_marker',
				data: {
					markers: self.markers,
					action: 'save'
				}
			}, function (response) {
				self.loader.hide();
				self.marker = self.getBlankMarker();
				self.toggleModal('formAdd');
				self.toast.success(response.msg);
			});
		},
		toggleEditModal(index, obj) {
			this.edited_marker.title = obj.title;
			this.edited_marker.content = obj.content;
			this.edited_marker.latitude = obj.latitude;
			this.edited_marker.longitude = obj.longitude;
			this.edited_index = index;
			this.toggleModal('formEdit');
		},
		toggleModal(str) {
			const f = document.getElementById(str);
			f.classList.toggle('active');
		},
		//triggered by button
		deleteMarker(i, obj) {
			const self = this;
			this.dialog.set(`¿Seguro que deseas eliminar este marcador: ${obj.title}?`, () => {
				self.loader.show();
				self.markers.splice(i, 1);
				self.fetch({
					type: 'save_marker',
					data: {
						markers: self.markers,
						action: 'delete'
					}
				}, function (response) {
					self.loader.hide();
					self.toast.success(response.msg);
				});
			})
		},
		updateMarker() {
			const self = this;
			this.markers[this.edited_index] = this.edited_marker;
			this.loader.show();
			this.fetch({
				type: 'save_marker',
				data: {
					markers: self.markers,
					action: 'update'
				}
			}, function (response) {
				self.loader.hide();
				self.edited_marker = self.getBlankMarker();
				self.toggleModal('formEdit');

				self.toast.success(response.msg);
			});
		},
		cancelModal(str) {
			this.toggleModal(str);
		},
		fetch(obj, callback) {
			var self = this;
			jQuery.ajax({
				url: ajaxurl,
				type: 'POST',
				data: {
					action: openstreetmapData.ajax_action,
					type: obj.type,
					data: obj.data
				},
				success: function (response) {
					const x = JSON.parse(response);
					if (typeof callback === 'function' && x.result === 'OK') {
						callback(x);
					}
					else {
						self.loader.hide();
						self.dialog.show({
							title: 'ERROR',
							message: x.msg
						});
					}
				},
				error: function (error) {
					self.loader.hide();
					self.dialog.show({
						title: 'ERROR',
						message: 'Request error code: ' + error.status
					});
				}
			});
		},
		updateMarkerColors() {
			const self = this;
			this.loader.show();
			this.fetch({
				type: 'update_marker_colors',
				data: {
					start_color: self.marker_start_color,
					end_color: self.marker_end_color
				}
			}, (response) => {
				self.loader.hide();
				// update openstreetmapData
				openstreetmapData.marker_start_color = self.marker_start_color
				openstreetmapData.marker_end_color = self.marker_end_color
				// toast
				self.toast.success(response.msg);
			});
		},
		restoreMarkerColors() {
			const self = this;
			this.loader.show();
			this.fetch({
				type: 'restore_marker_colors',
				data: {
					start_color: self.marker_start_color,
					end_color: self.marker_end_color
				}
			}, (response) => {
				self.loader.hide();
				// update openstreetmapData
				openstreetmapData.marker_start_color = openstreetmapData.marker_default_start_color;
				openstreetmapData.marker_end_color = openstreetmapData.marker_default_end_color;
				self.marker_start_color = openstreetmapData.marker_default_start_color;
				self.marker_end_color = openstreetmapData.marker_default_end_color;
				// toast
				self.toast.success(response.msg);
			});
		}
	}
}).mount('#markersonopenstreetmap');