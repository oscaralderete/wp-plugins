<?php
/**
Plugin Name: Markers On OpenStreetMap
Plugin URI: https://wpe.oscaralderete.com
Description: ¿Tu website necesita un mapa con múltiple marcadores? Tenemos esta solución para ti hecha usando OpenStreetMap, que a diferencia de GoogleMaps no necesita claves de configuración, ni crear aplicaciones en la consola de Google y además es 100% gratuita ya sea que tengas cien, mil o un millón de visitas al día. Ampliamente configurable (incluso puedes personalizar los colores de tu marcador), esta versión está hecha especialmente para el Perú pero puede usarse en cualquier website del mundo.
Version: 1.0.0
Author: WPE - Oscar Alderete <wpe@oscaralderete.com>
Author URI: https://wpe.oscaralderete.com
License: GPL v2 or later
*/
if(!defined('WPINC')){
	die;
}

require plugin_dir_path(__FILE__) . 'includes/MarkersOnOpenStreetMap.php';

new \WebappsParaEmprendedores\MarkersOnOpenStreetMap(__FILE__);