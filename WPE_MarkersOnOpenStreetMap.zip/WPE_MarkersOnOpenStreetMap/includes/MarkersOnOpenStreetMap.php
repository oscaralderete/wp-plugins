<?php
/*
@author: Oscar Alderete <wordpress@oscaralderete.com>
@website: https://wpe.oscaralderete.com
@editor: NetBeans IDE v11.2
*/
namespace WebappsParaEmprendedores;

class MarkersOnOpenStreetMap {

private $uri;
private $path;
private $s = ['result'=>'ERROR', 'msg'=>'Error code 3001'];
private $scripts = [
	['type'=>'remote', 'src'=>'https://unpkg.com/leaflet@1.7.1/dist/leaflet.js'],
	['type'=>'local', 'src'=>'scripts.js']
];
private $adminScripts = [
	['type'=>'local', 'src'=>'vue.3.2.20.js', 'folder'=>'admin'],
	['type'=>'local', 'src'=>'oa-toast.js', 'folder'=>'admin'],
	['type'=>'local', 'src'=>'oa-dialogs.js', 'folder'=>'admin'],
	['type'=>'local', 'src'=>'scripts.js', 'folder'=>'admin']
];
private $styles = [
	['type'=>'remote', 'src'=>'https://unpkg.com/leaflet@1.7.1/dist/leaflet.css'],
	['type'=>'local', 'src'=>'styles.css']
];
private $adminStyles = [
	['type'=>'local', 'src'=>'oa-loader.css', 'folder'=>'admin'],
	['type'=>'local', 'src'=>'oa-toast.css', 'folder'=>'admin'],
	['type'=>'local', 'src'=>'oa-dialogs.css', 'folder'=>'admin'],
	['type'=>'local', 'src'=>'styles.css', 'folder'=>'admin']
];
private $marker = '<svg class="marker-shadow" viewBox="0 0 32 40" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" x="0" y="0" width="32" height="40"><defs><linearGradient id="grad" x1="50%" y1="0%" x2="50%" y2="100%"><stop stop-color="$startColor" stop-opacity="1" offset="25%"/><stop stop-color="$endColor" stop-opacity="1" offset="100%"/></linearGradient></defs><path d="M 15.9999 0 C 7.1631 0 0 7.1397 0 15.9463 C 0 17.3282 0.1758 18.6692 0.5078 19.947 C 0.8141 21.1292 1.2587 22.2557 1.8116 23.3155 C 4.3216 28.1251 15.9999 40 15.9999 40 C 15.9999 40 27.6973 27.8427 30.1877 23.3155 C 30.7633 22.2677 31.1853 21.1292 31.4915 19.947 C 31.8229 18.6692 32 17.3282 32 15.9463 C 32 7.1397 24.8362 0 15.9999 0 Z" fill="url(#grad)"/><circle cx="16" cy="16" r="10" stroke="#dbdbea" stroke-width="2" fill="#fafafa"/></svg>';


const CODE = 'MarkersOnOpenStreetMap';
const SLUG = 'markersonopenstreetmap';
const GLOBAL = self::SLUG . '_global';
const TITLE = 'Markers On OpenStreetMap';
const PERMISSION = 'administrator';
const ICON = 'dashicons-location';
const VERSION = '1.0.0';
const AJAX_ADMIN_LISTENER = '_process_ajax_request';
const MARKER_START_COLOR = '#00A5E5';
const MARKER_END_COLOR = '#12499B';
const WPE_EMAIL = 'wpe@oscaralderete.com';


// constructor
function __construct(string $file){
	$this->uri = plugin_dir_url($file);
	$this->path = plugin_dir_path($file);

	// add shortcode
	add_shortcode(self::CODE, [$this, 'get_public_view']);

	// register scripts to use 
	add_action('wp_enqueue_scripts', [$this, 'load_public_scripts'], 2);

	// admin page
	add_action('admin_menu', [$this, 'admin_menu']);

	// register plugin settings
	add_action('admin_init', [$this, 'admin_init'], 3);

	// register scripts to use 
	add_action('admin_enqueue_scripts', [$this, 'load_admin_scripts'], 3);

	// ajax request listener
	add_action('wp_ajax_' . self::SLUG . self::AJAX_ADMIN_LISTENER, [$this, 'process_ajax_request'], 4);
}


// publics
public function load_public_scripts(){
	if($GLOBALS[self::GLOBAL]['enabled']){
		$this->loadScripts('public');
	}
}

public function load_admin_scripts(){
	if(isset($_GET['page']) && $_GET['page'] === self::SLUG . '/admin-page'){
		$this->loadScripts('admin');
	}
}

public function get_public_view(){
	global ${self::GLOBAL};
	${self::GLOBAL} = ['enabled' => true];

	return $this->getView('public');
}

public function admin_menu(){
	$t = self::TITLE;
	add_menu_page($t, $t, self::PERMISSION, self::SLUG . '/admin-page', function(){
		echo $this->getView('admin');
	}, self::ICON, 6);
}

public function admin_init(){
	register_setting(self::SLUG, self::SLUG . '_markers');
	register_setting(self::SLUG, self::SLUG . '_map_height');
	register_setting(self::SLUG, self::SLUG . '_initial_zoom');
	register_setting(self::SLUG, self::SLUG . '_marker_start_color');
	register_setting(self::SLUG, self::SLUG . '_marker_end_color');
}

public function process_ajax_request(){
	$s = $this->s;
	switch($_POST['type']){
		case 'save_marker':
			$s = $this->saveMarkers($_POST['data']);
			break;
		case 'save_initial_zoom':
			$s = $this->saveInitialZoom($_POST['data']);
			break;
		case 'save_map_height':
			$s = $this->saveMapHeight($_POST['data']);
			break;
		case 'update_marker_colors':
			$s = $this->updateMarkerColors($_POST['data']);
			break;
		case 'restore_marker_colors':
			$s = $this->restoreMarkerColors($_POST['data']);
			break;
		default:
			$s['msg'] = 'Error de código 2001.';
	}
	sleep(1);
	echo json_encode($s);
	wp_die();
}


// privates
private function loadScripts(string $zone){
	$handle = self::CODE . '_js';
	$order = 1;
	$scripts = $zone == 'public' ? $this->scripts : $this->adminScripts;
	foreach($scripts as $i) {
		if($i['type'] == 'local'){
			$uri = $this->uri . (isset($i['folder']) ? $i['folder'] : 'public') . '/js/' . $i['src'];
			$version = self::VERSION;
			$onFooter = true;
		}
		else{
			$uri = $i['src'];
			$version = null;
			$onFooter = false;
		}
		wp_register_script($handle . $order, $uri, [], $version, $onFooter);
		wp_enqueue_script($handle . $order);
		$order++;
	}
	// styles
	$styles = $zone == 'public' ? (isset($this->styles) ? $this->styles : []) : (isset($this->adminStyles) ? $this->adminStyles : []);
	$handle = self::CODE . '_css';
	$order = 1;
	foreach($styles as $i) {
		if($i['type'] == 'local'){
			$uri = $this->uri . (isset($i['folder']) ? $i['folder'] : 'public') . '/css/' . $i['src'];
			$version = self::VERSION;
			$onFooter = true;
		}
		else{
			$uri = $i['src'];
			$version = null;
			$onFooter = false;
		}
		wp_enqueue_style($handle . $order, $uri, [], $version);
		$order++;
	}
}

private function getView(string $type){
	// default
	$bus = ['$pageData'];
	$rem = [];
	// markers
	if($r = get_option(self::SLUG . '_markers')){
		$markers = unserialize($r);
	}
	else{
		$markers = [];
	}
	// map height
	if($r = get_option(self::SLUG . '_map_height')){
		$map_height = $r;
	}
	else{
		$map_height = 200;
	}
	// map's initial zoom
	if($r = get_option(self::SLUG . '_initial_zoom')){
		$initial_zoom = (int)$r;
	}
	else{
		$initial_zoom = 10;
	}
	// marker start color
	$marker_start_color = $this->getMarkerOptionColor('start');
	// marker end color
	$marker_end_color = $this->getMarkerOptionColor('end');
	switch($type){
		case 'admin':
			$view = 'admin/template/settings';
			//preparing page data
			$rem[] = json_encode([
				'markers' => $markers,
				'ajax_action' => self::SLUG . '_process_ajax_request',
				'map_height' => $map_height,
				'initial_zoom' => $initial_zoom,
				'marker_start_color' => $marker_start_color,
				'marker_end_color' => $marker_end_color,
				'marker_default_start_color' => self::MARKER_START_COLOR,
				'marker_default_end_color' => self::MARKER_END_COLOR,
				'wpe_email' => self::WPE_EMAIL
			]);
			break;
		default:
			$view = 'public/template/openstreetmap';
			//preparing page data
			$rem[] = json_encode([
				'markers' => $markers,
				'marker_uri' => $this->uri . 'public/img/marker.svg',
				'marker_shadow' => $this->uri . 'public/img/marker_shadow.png',
				'map_height' => $map_height,
				'lat' => -12.0459939284752,
				'lng' => -77.0305538177490,
				'initial_zoom' => $initial_zoom
			]);
	}
	return str_replace($bus, $rem, file_get_contents($this->path . $view . '.html'));
}

private function saveMarkers(array $post){
	$s = $this->s;
	$key = 'markers';
	$option = self::SLUG . '_' . $key;
	// save/update option
	if(update_option($option, serialize($post[$key]))){
		$s['result'] = 'OK';
		// for english version only:
		// $s['msg'] = 'Marker has been ' . $post['action'] . 'd!';
		$s['msg'] = 'El marcador ha sido correctamente ' . ($post['action'] == 'save' ? 'grabado' : 'actualizado') . '.';
	}
	else{
		$s['msg'] = 'Se produjo un error al procesar esta acción.';
	}
	return $s;
}

private function saveInitialZoom(array $post){
	$s = $this->s;
	$key = 'initial_zoom';
	$option = self::SLUG . '_' . $key;
	// check for changes
	$googleMapKey = get_option($option);
	if($googleMapKey == $post[$key]){
		// for english version only:
		// $s['msg'] = 'Nothing to update because API key hasn\'t changed!';
		$s['msg'] = 'No se grabó nada pues el valor no ha cambiado.';
		return $s;
	}
	// force values when exceeding the valid range
	$post[$key] = (int)$post[$key];
	if($post[$key] > 0 && $post[$key] < 19){
		// everything's ok
		$force = false;
	}
	else{
		$force = true;
		$post[$key] = $post[$key] < 1 ? 1 : 18;
	}
	// save/update option
	if(update_option($option, $post[$key])){
		$s['result'] = 'OK';
		// for english version only:
		// $s['msg'] = 'The initial zoom has been updated!';
		$s['msg'] = 'El zoom del mapa ha sido actualizado.';
		$s[$key] = $post[$key];
	}
	else{
		if($force){
			$s['result'] = 'OK';
			// for english version only:
			// $s['msg'] = 'The initial zoom has been updated!';
			$s['msg'] = 'El zoom del mapa ha sido actualizado.';
			$s[$key] = $post[$key];
		}
		else{
			// for english version only:
			// $s['msg'] = 'Error trying to save the initial zoom!';
			$s['msg'] = 'Se produjo un error al procesar esta acción.';
		}
	}
	return $s;
}

private function saveMapHeight(array $post){
	$s = $this->s;
	$key = 'map_height';
	$option = self::SLUG . '_' . $key;
	// check for changes
	$map_height = get_option($option);
	if($map_height == $post[$key]){
		// for english version only:
		// $s['msg'] = 'Nothing to update because map height hasn\'t changed!';
		$s['msg'] = 'No se grabó nada pues el valor no ha cambiado.';
		return $s;
	}
	// save/update option
	if(update_option($option, $post[$key])){
		$s['result'] = 'OK';
		// for english version only:
		// $s['msg'] = 'Your map height has been updated!';
		$s['msg'] = 'La altura de tu mapa ha sido actualizada.';
	}
	else{
		// for english version only:
		// $s['msg'] = 'Error trying to save map height!';
		$s['msg'] = 'Se produjo un error al procesar esta acción.';
	}
	return $s;
}

private function getMarkerOptionColor(string $key){
	$s = $key == 'end' ? self::MARKER_END_COLOR : self::MARKER_START_COLOR;
	if($r = get_option(self::SLUG . '_marker_' . $key . '_color')){
		$s = $r;
	}
	return $s;
}

private function updateMarkerColors(array $post){
	$s = $this->s;
	// check for changes
	$startColor = $this->getMarkerOptionColor('start');
	$endColor = $this->getMarkerOptionColor('end');
	$changes = 0;
	if($startColor != $post['start_color']){
		if(update_option(self::SLUG . '_marker_start_color', $post['start_color'])){
			$changes++;
		}
	}
	if($endColor != $post['end_color']){
		if(update_option(self::SLUG . '_marker_end_color', $post['end_color'])){
			$changes++;
		}
	}
	// save/update option
	if($changes > 0){
		if($this->writeMarkerSvg($post['start_color'], $post['end_color'])){
			$s['result'] = 'OK';
			$s['msg'] = 'Tu marcador ha sido regenerado con los colores indicados.';
		}
		else{
			$s['msg'] = 'Se produjo un error al procesar esta acción.';
		}
	}
	else{
		$s['msg'] = 'No se actualizó nada pues los valores no han cambiado.';
	}
	return $s;
}

private function restoreMarkerColors(array $post){
	$s = $this->s;
	// check for changes
	$changes = 0;
	if(self::MARKER_START_COLOR != $post['start_color'] || self::MARKER_END_COLOR != $post['end_color']){
		// process
		if($this->writeMarkerSvg(self::MARKER_START_COLOR, self::MARKER_END_COLOR)){
			update_option(self::SLUG . '_marker_start_color', self::MARKER_START_COLOR);
			update_option(self::SLUG . '_marker_end_color', self::MARKER_END_COLOR);
			$s['result'] = 'OK';
			$s['msg'] = 'Tu marcador ha sido regenerado con los colores originales.';
		}
		else{
			$s['msg'] = 'Se produjo un error al procesar esta acción.';
		}
	}
	else{
		$s['msg'] = 'No se actualizó nada pues los valores no han cambiado.';
	}
	return $s;
}

private function writeMarkerSvg(string $startColor, string $endColor){
	$marker = str_replace(['$startColor', '$endColor'], [$startColor, $endColor], $this->marker);
	return file_put_contents($this->path . 'public/img/marker.svg', $marker) == false ? false : true;
}

}