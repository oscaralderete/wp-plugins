/*!
Developed by Web+apps Para Emprendedores
@author: Oscar Alderete <oscaralderete@gmail.com>
@website: https://wpe.oscaralderete.com
*/
if (typeof openstreetmapData !== 'undefined') {
	const MarkersOnOpenStreetMap = {
		bounds: [],
		mapId: 'openstreetmap',
		map: null,
		icon: L.icon({
			iconUrl: openstreetmapData.marker_uri,
			shadowUrl: openstreetmapData.marker_shadow,
			iconSize: [32, 40], // size of the icon
			shadowSize: [28, 25],
			iconAnchor: [16, 40], // point of the icon which will correspond to marker's location
			shadowAnchor: [10, 18],
			popupAnchor: [0, -42] // point from which the popup should open relative to the iconAnchor
		}),
		init() {
			// check if exist markers
			if (openstreetmapData.markers.length === 0) {
				alert('MarkersOnOpenStreetMap Plugin\nYou need to enter some markers!');
				return false;
			}

			// proceed
			const x = document.getElementById(this.mapId);
			x.style.height = `${openstreetmapData.map_height}px`;

			// tiles, 'L' refers to Leaflet
			this.map = L.map(this.mapId).setView([openstreetmapData.lat, openstreetmapData.lng], openstreetmapData.initial_zoom);
			L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
				attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>',
				maxZoom: 18,
				tileSize: 256,
				zoomOffset: 0
			}).addTo(this.map);

			// adding markers
			openstreetmapData.markers.forEach(obj => {
				let lat = parseFloat(obj.latitude);
				let lng = parseFloat(obj.longitude);
				L.marker([lat, lng], { icon: this.icon })
					.addTo(this.map)
					.bindPopup(`<p class="map-info"><b>${obj.title}</b><br>${obj.content}</p>`)
					.openPopup();

				// avoid redirections

				// populate bounds array
				this.bounds.push([lat, lng]);
			});

			// center map between bounds
			this.map.fitBounds(this.bounds);

			const y = x.querySelectorAll('a.leaflet-popup-close-button');

			for (let i = 0; i < y.length; i++) {
				y[i].removeAttribute('href')
			}
		},
	};

	MarkersOnOpenStreetMap.init();

}