<?php
/**
Plugin Name: Multiple Markers On Google Map
Plugin URI: https://wpe.oscaralderete.com
Description: Este plugin te permite tener un mapa de GoogleMaps con múltiples marcadores en tu sitio web. Ten en cuenta que debido a las políticas de Google, necesitas tener una clave API de tu cuenta de Google. Esta versión ha sido refactorizada e incluye ahora un personalizador de los colores del marcador. Aunque ha sido hecha especialmente para el Perú puede usarse en cualquier website del mundo.
Version: 1.0
Author: WPE - Oscar Alderete <wpe@oscaralderete.com>
Author URI: https://wpe.oscaralderete.com
License: GPL v2 or later
*/
if(!defined('WPINC')){
	die;
}

require plugin_dir_path(__FILE__) . 'includes/MultiMarkersOnGmap.php';

new \WebappsParaEmprendedores\MultiMarkersOnGmap(__FILE__);