<?php
/*
@author: Oscar Alderete <wordpress@oscaralderete.com>
@website: https://wpe.oscaralderete.com
@editor: NetBeans IDE v11.2
*/
namespace WebappsParaEmprendedores;

class MultiMarkersOnGmap {

	private $uri;
	private $path;
	private $s = ['result'=>'ERROR', 'msg'=>'Error code 3001'];
	private $scripts = [
		['type'=>'remote', 'src'=>'https://maps.googleapis.com/maps/api/js'],
		['type'=>'local', 'src'=>'scripts.js']
	];
	private $adminScripts = [
		['type'=>'local', 'src'=>'vue.3.1.1.js'],
		['type'=>'local', 'src'=>'oa-toast.js', 'folder'=>'admin'],
		['type'=>'local', 'src'=>'oa-dialogs.js', 'folder'=>'admin'],
		['type'=>'local', 'src'=>'scripts.js', 'folder'=>'admin']
	];
	private $styles = [
		['type'=>'local', 'src'=>'styles.css']
	];
	private $adminStyles = [
		['type'=>'local', 'src'=>'oa-loader.css', 'folder'=>'admin'],
		['type'=>'local', 'src'=>'oa-toast.css', 'folder'=>'admin'],
		['type'=>'local', 'src'=>'oa-dialogs.css', 'folder'=>'admin'],
		['type'=>'local', 'src'=>'styles.css', 'folder'=>'admin']
	];
	private $marker = '<svg class="marker-shadow" viewBox="0 0 32 40" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" xml:space="preserve" x="0" y="0" width="32" height="40"><defs><linearGradient id="grad" x1="50%" y1="0%" x2="50%" y2="100%"><stop stop-color="$startColor" stop-opacity="1" offset="25%"/><stop stop-color="$endColor" stop-opacity="1" offset="100%"/></linearGradient></defs><path d="M 15.9999 0 C 7.1631 0 0 7.1397 0 15.9463 C 0 17.3282 0.1758 18.6692 0.5078 19.947 C 0.8141 21.1292 1.2587 22.2557 1.8116 23.3155 C 4.3216 28.1251 15.9999 40 15.9999 40 C 15.9999 40 27.6973 27.8427 30.1877 23.3155 C 30.7633 22.2677 31.1853 21.1292 31.4915 19.947 C 31.8229 18.6692 32 17.3282 32 15.9463 C 32 7.1397 24.8362 0 15.9999 0 Z" fill="url(#grad)"/><circle cx="16" cy="16" r="10" stroke="#dbdbea" stroke-width="2" fill="#fafafa"/></svg>';

	const CODE = 'MultiMarkersOnGmap';
	const SLUG = 'multimarkersongmap';
	const GLOBAL = self::SLUG .'_global';
	const TITLE = 'Multi Markers On Gmap';
	const AJAX_ADMIN_LISTENER = '_process_ajax_request';
	const PERMISSION = 'administrator';
	const ICON = 'dashicons-location';
	const VERSION = '1.0.0';
	const MARKER_START_COLOR = '#B10011';
	const MARKER_END_COLOR = '#6A000A';
	const WPE_EMAIL = 'wpe@oscaralderete.com';
	const DEF_LAT = -12.0459939284752;
	const DEF_LNG = -77.0305538177490;

	function __construct(string $path){
		$this->uri = plugin_dir_url($path);
		$this->path = plugin_dir_path($path);

		// shortcode
		add_shortcode(self::CODE, [$this, 'get_view']);

		// register scripts to use 
		add_action('wp_enqueue_scripts', [$this, 'enqueue_public_scripts'], 1);

		// admin page
		add_action('admin_menu', [$this, 'admin_menu'], 2);

		// register plugin settings
		add_action('admin_init', [$this, 'admin_init'], 3);

		// register scripts to use 
		add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts'], 4);

		// ajax request listener
		add_action('wp_ajax_' . self::SLUG . self::AJAX_ADMIN_LISTENER, [$this, 'process_ajax_request'], 5);
	}


	//publics
	public function get_view(){
		global ${self::GLOBAL};
		${self::GLOBAL} = ['enabled' => true];

		return $this->getView('public');
	}

	public function enqueue_public_scripts(){
		if($GLOBALS[self::GLOBAL]['enabled']){
			// add key to Google maps API url
			$this->overpassScripts();
			// load scripts + styles
			$this->loadScripts('public');
		}
	}

	public function admin_menu(){
		$t = self::TITLE;
		add_menu_page($t, $t, self::PERMISSION, self::SLUG . '/admin-page', function(){
			echo $this->getView('admin');
		}, self::ICON, 6);
	}

	public function admin_init(){
		register_setting(self::SLUG, self::SLUG . '_google_map_key');
		register_setting(self::SLUG, self::SLUG . '_markers');
		register_setting(self::SLUG, self::SLUG . '_map_height');
		register_setting(self::SLUG, self::SLUG . '_marker_start_color');
		register_setting(self::SLUG, self::SLUG . '_marker_end_color');
	}

	public function enqueue_admin_scripts(){
		if(isset($_GET['page']) && $_GET['page'] === self::SLUG . '/admin-page'){
			$this->loadScripts('admin');
		}
	}

	public function process_ajax_request(){
		$s = $this->s;
		switch($_POST['type']){
			case 'save_marker':
				$s = $this->saveMarkers($_POST['data']);
				break;
			case 'save_api_key':
				$s = $this->saveApiKey($_POST['data']);
				break;
			case 'save_map_height':
				$s = $this->saveMapHeight($_POST['data']);
				break;
			case 'update_marker_colors':
				$s = $this->updateMarkerColors($_POST['data']);
				break;
			case 'restore_marker_colors':
				$s = $this->restoreMarkerColors($_POST['data']);
				break;
			default:
				$s['msg'] = 'Error code 2001';
		}
		sleep(1);
		echo json_encode($s);
		wp_die();
	}
	

	// privates
	private function overpassScripts(){
		// google maps key
		if($googleMapKey = get_option(self::SLUG . '_google_map_key')){
			// option already exists
		}
		else{
			$googleMapKey = '';
		}
		$this->scripts[0]['src'] .= '?key=' . $googleMapKey;
	}

	private function loadScripts(string $zone){
		$handle = self::CODE . '_js';
		$order = 1;
		$scripts = $zone == 'public' ? $this->scripts : $this->adminScripts;
		foreach($scripts as $i) {
			if($i['type'] == 'local'){
				$uri = $this->uri . (isset($i['folder']) ? $i['folder'] : 'public') . '/js/' . $i['src'];
				$version = self::VERSION;
				$onFooter = true;
			}
			else{
				$uri = $i['src'];
				$version = null;
				$onFooter = false;
			}
			wp_register_script($handle . $order, $uri, [], $version, $onFooter);
			wp_enqueue_script($handle . $order);
			$order++;
		}
		// styles
		$styles = $zone == 'public' ? (isset($this->styles) ? $this->styles : []) : (isset($this->adminStyles) ? $this->adminStyles : []);
		$handle = self::CODE . '_css';
		$order = 1;
		foreach($styles as $i) {
			if($i['type'] == 'local'){
				$uri = $this->uri . (isset($i['folder']) ? $i['folder'] : 'public') . '/css/' . $i['src'];
				$version = self::VERSION;
				$onFooter = true;
			}
			else{
				$uri = $i['src'];
				$version = null;
				$onFooter = false;
			}
			wp_enqueue_style($handle . $order, $uri, [], $version);
			$order++;
		}
	}

	private function getView(string $type){
		// default
		$bus = ['$pageData'];
		$rem = [];
		// markers
		if($r = get_option(self::SLUG . '_markers')){
			$markers = unserialize($r);
		}
		else{
			$markers = [];
		}
		// map height
		if($r = get_option(self::SLUG . '_map_height')){
			$map_height = $r;
		}
		else{
			$map_height = 300;
		}
		// marker start color
		$marker_start_color = $this->getMarkerOptionColor('start');
		// marker end color
		$marker_end_color = $this->getMarkerOptionColor('end');
		switch($type){
			case 'admin':
				// google maps key
				if($googleMapKey = get_option(self::SLUG . '_google_map_key')){
					//option already exists
				}
				else{
					$googleMapKey = '';
				}
				$view = 'admin/template/settings';
				// preparing page data
				$rem[] = json_encode([
					'key' => $googleMapKey,
					'markers' => $markers,
					'ajax_action' => self::SLUG . '_process_ajax_request',
					'map_height' => $map_height,
					'marker_start_color' => $marker_start_color,
					'marker_end_color' => $marker_end_color,
					'marker_default_start_color' => self::MARKER_START_COLOR,
					'marker_default_end_color' => self::MARKER_END_COLOR,
					'wpe_email' => self::WPE_EMAIL
				]);
				break;
			default:
				$view = 'public/template/gmap';
				// preparing page data
				$rem[] = json_encode([
					'markers' => $markers,
					'marker_uri' => $this->uri . 'public/img/marker.svg',
					'map_height' => $map_height,
					'lat' => self::DEF_LAT,
					'lng' => self::DEF_LNG
				]);
		}
		return str_replace($bus, $rem, file_get_contents($this->path . $view . '.html'));
	}

	private function saveMarkers(array $post){
		$s = $this->s;
		// save/update option
		if(update_option(self::SLUG . '_markers', serialize($post['markers']))){
			$s['result'] = 'OK';
			$s['msg'] = 'Marcador correctamente ' . ($post['action'] == 'save' ? 'grabado' : 'actualizado') . '.';
		}
		else{
			$s['msg'] = 'Se produjo un error al procesar esta acción.';
		}
		return $s;
	}

	private function saveApiKey(array $post){
		$s = $this->s;
		// check for changes
		$option = self::SLUG . '_google_map_key';
		$googleMapKey = get_option($option);
		if($googleMapKey == $post['key']){
			$s['msg'] = 'No se actualizó nada pues el valor original no ha cambiado.';
			return $s;
		}
		// save/update option
		if(update_option($option, $post['key'])){
			$s['result'] = 'OK';
			$s['msg'] = 'Tu clave API fue actualizada.';
		}
		else{
			$s['msg'] = 'Se produjo un error al procesar esta acción.';
		}
		return $s;
	}

	private function saveMapHeight(array $post){
		$s = $this->s;
		$key = 'map_height';
		// option key
		$opk = self::SLUG . '_' . $key;
		// check for changes
		$map_height = get_option($opk);
		if($map_height == $post[$key]){
			$s['msg'] = 'No se actualizó nada pues el valor original no ha cambiado.';
			return $s;
		}
		// save/update option
		if(update_option($opk, $post[$key])){
			$s['result'] = 'OK';
			$s['msg'] = 'La altura de tu mapa ha sido actualizada.';
		}
		else{
			$s['msg'] = 'Se produjo un error al procesar esta acción.';
		}
		return $s;
	}

	private function updateMarkerColors(array $post){
		$s = $this->s;
		//check for changes
		$startColor = $this->getMarkerOptionColor('start');
		$endColor = $this->getMarkerOptionColor('end');
		$changes = 0;
		if($startColor != $post['start_color']){
			if(update_option(self::SLUG . '_marker_start_color', $post['start_color'])){
				$changes++;
			}
		}
		if($endColor != $post['end_color']){
			if(update_option(self::SLUG . '_marker_end_color', $post['end_color'])){
				$changes++;
			}
		}
		// save/update option
		if($changes > 0){
			if($this->writeMarkerSvg($post['start_color'], $post['end_color'])){
				$s['result'] = 'OK';
				$s['msg'] = 'Tu marcador ha sido regenerado con los colores indicados.';
			}
			else{
				$s['msg'] = 'Se produjo un error al procesar esta acción.';
			}
		}
		else{
			$s['msg'] = 'No se actualizó nada pues los valores no han cambiado.';
		}
		return $s;
	}

	private function restoreMarkerColors(array $post){
		$s = $this->s;
		// check for changes
		$changes = 0;
		if(self::MARKER_START_COLOR != $post['start_color'] || self::MARKER_END_COLOR != $post['end_color']){
			// process
			if($this->writeMarkerSvg(self::MARKER_START_COLOR, self::MARKER_END_COLOR)){
				update_option(self::SLUG . '_marker_start_color', self::MARKER_START_COLOR);
				update_option(self::SLUG . '_marker_end_color', self::MARKER_END_COLOR);
				$s['result'] = 'OK';
				$s['msg'] = 'Tu marcador ha sido regenerado con los colores originales.';
			}
			else{
				$s['msg'] = 'Se produjo un error al procesar esta acción.';
			}
		}
		else{
			$s['msg'] = 'No se actualizó nada pues los valores no han cambiado.';
		}
		return $s;
	}

	private function getMarkerOptionColor(string $key){
		$s = $key == 'end' ? self::MARKER_END_COLOR : self::MARKER_START_COLOR;
		if($r = get_option(self::SLUG . '_marker_' . $key . '_color')){
			$s = $r;
		}
		return $s;
	}

	private function writeMarkerSvg(string $startColor, string $endColor){
		$marker = str_replace(['$startColor', '$endColor'], [$startColor, $endColor], $this->marker);
		return file_put_contents($this->path . 'public/img/marker.svg', $marker) == false ? false : true;
	}
}