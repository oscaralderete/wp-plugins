<?php
/**
Plugin Name: Campos BOLETA/FACTURA y DNI/RUC
Plugin URI: https://wpe.oscaralderete.com
Description: Este plugin está hecho específicamente para WooCommerce. Le agrega al formulario de compra los campos FACTURA/BOLETA y DNI/RUC, con otro campo para la razón social en caso de empresas. Adicionalmente quita el campo "Company name" del formulario, pues queda fuera de lugar con los nuevos campos añadidos. Estos nuevos datos aparecerán en la zona de administración de WooCommerce para su gestión.
Version: 1.0.0
Author: WPE - Oscar Alderete <wpe@oscaralderete.com>
Author URI: https://wpe.oscaralderete.com
License: GPL v2 or later
*/
if(!defined('WPINC')){
	die;
}

// load only if WooCommerce is active
if(in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))){
	require plugin_dir_path(__FILE__) . 'includes/FieldsBoletaFactura.php';

	new \WebappsParaEmprendedores\WooCommerce\FieldsBoletaFactura(__FILE__);
}