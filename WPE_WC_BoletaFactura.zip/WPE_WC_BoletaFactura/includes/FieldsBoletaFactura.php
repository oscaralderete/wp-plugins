<?php
/*
@author: Oscar Alderete <wordpress@oscaralderete.com>
@website: https://wpe.oscaralderete.com
@editor: NetBeans IDE v12.1
*/
namespace WebappsParaEmprendedores\WooCommerce;

class FieldsBoletaFactura {

	private $uri;
	private $path;
	private $s = ['result' => 'ERROR', 'msg' => 'Error code 3001'];
	private $billTypes = [
		'Boleta' => 'Boleta',
		'Factura' => 'Factura'
	];
	private $customFieldsKeys = ['tipo_comprobante', 'dni', 'razon_social', 'ruc'];
	private $customFields = [];
	private $plainEmailTemplate = "
COMPROBANTE DE PAGO
Tipo: %tipoComprobante%
%detail%
";
	private $plainEmailBill = "
DNI: %dni%
";
	private $plainEmailInvoice = "
RUC: %ruc%
Razón social: %razonSocial%
";

	const CODE = 'WPE_WC_BillInvoice';
	const SLUG = 'wpe_wc_billinvoice';
	const ABREV = 'WPE_WC_FBF_';
	const TITLE = '';
	const PERMISSION = 'administrator';
	const ICON = 'dashicons-location';
	const VERSION = '1.0.0';
	const AJAX_ADMIN_LISTENER = '_process_ajax_request';
	const WPE_EMAIL = 'wpe@oscaralderete.com';

	function __construct(string $path) {
		$this->uri = plugin_dir_url($path);
		$this->path = plugin_dir_path($path);

		// update order meta
		add_action('woocommerce_checkout_update_order_meta', [$this, 'update_order_meta'], 10);

		// display info on admin zone
		add_action('woocommerce_admin_order_data_after_billing_address', [$this, 'display_custom_fields_on_admin'], 11);

		// add custom fields filter
		add_filter('woocommerce_checkout_fields', [$this, 'add_custom_fields']);

		// register scripts + styles
		add_action('wp_enqueue_scripts', [$this, 'load_public_scripts'], 2);

		// display data on order processed thank you page
		add_action('woocommerce_thankyou', [$this, 'thank_you_page']);

		// 
		add_action('woocommerce_email_order_meta', [$this, 'order_thank_you_email'], 10, 3);
	}

	// publics
	public function update_order_meta($order_id) {
		// custom fields
		foreach($this->customFieldsKeys as $i){
			if(!empty($_POST[self::ABREV . $i])){
				update_post_meta($order_id, '_' . self::ABREV . $i, sanitize_text_field($_POST[self::ABREV . $i]));
			}
		}
	}

	public function display_custom_fields_on_admin($order) {
		$this->getCustomFields($order->id);

		// get view based on bill type
		echo $this->getOrderDetailInAdmin($this->customFields['tipo_comprobante']);
	}

	public function add_custom_fields(array $fields) {
		// custom fields options: tipo de comprobante
		$fields['billing'][self::ABREV . 'tipo_comprobante'] = [
			'label' => __('Tipo de comprobante de pago', 'woocommerce'),
			'type' => 'select',
			'required' => true, 
			'class' => array('form-row-wide', 'address-field'),
			'clear' => true,
			'options' => $this->billTypes
		];
		$fields['billing'][self::ABREV . 'dni'] = [
			'label' => __('Número de documento de identidad', 'woocommerce'),
			'type' => 'text',
			'required' => true,
			'class' => array('form-row-wide', 'address-field', self::ABREV . 'boleta'),
			'clear' => true
		];
		$fields['billing'][self::ABREV . 'razon_social'] = [
			'label' => __('Razón social de su empresa', 'woocommerce'),
			'type' => 'text',
			'required' => true,
			'class' => array('form-row-wide', 'address-field', self::ABREV . 'hidden', self::ABREV . 'factura'),
			'clear' => true,
			'value' => 'NN'
		];
		$fields['billing'][self::ABREV . 'ruc'] = [
			'label' => __('Número de RUC', 'woocommerce'),
			'type' => 'text',
			'required' => true,
			'class' => array('form-row-wide', 'address-field', self::ABREV . 'hidden', self::ABREV . 'factura'),
			'clear' => true,
			'value' => '00000000000'
		];

		// remove fields
		unset($fields['billing']['billing_company']);
		unset($fields['shipping']['shipping_company']);

		return $fields;
	}

	public function load_public_scripts() {
		// only on checkout page
		if(!is_checkout() && !is_wc_endpoint_url()){
			return;
		}

		// vars
		$handle = self::CODE . '_js';
		$order = 1;
		$onFooter = true;

		// custom styles
		wp_enqueue_style($handle . $order, $this->uri . 'public/css/styles.css', [], self::VERSION);
		// custom scripts
		wp_register_script($handle . $order, $this->uri . 'public/js/scripts.js', [], self::VERSION, $onFooter);
		wp_enqueue_script($handle . $order);
	}

	public function thank_you_page($order_id) {
		$this->getCustomFields($order_id);
		echo $this->getThankYouLI($this->customFields['tipo_comprobante']);
	}

	public function order_thank_you_email($order, $sent_to_admin, $plain_text) {		//($fields, $sent_to_admin, $order) {
		$this->getCustomFields($order->id);
		$bt = $this->customFields['tipo_comprobante'];
		if($plain_text){
			$detail = str_replace(['%dni%', '%ruc%', '%razonSocial%'], [$this->customFields['dni'], $this->customFields['ruc'], $this->customFields['razon_social']], $bt == 'Factura' ? $this->plainEmailInvoice : $this->plainEmailBill);
			// final replacement
			$msg = str_replace(['%tipoComprobante%', '%detail%'], [$bt, $detail], $this->plainEmailTemplate);
			echo "Comprobante de pago\nAnother line...";
		}
		else{
			echo $this->getThankYouLI($bt);
		}
	}

	// privates
	private function getCustomFields($order_id) {
		foreach($this->customFieldsKeys as $i){
			$this->customFields[$i] = get_post_meta($order_id, '_' . self::ABREV . $i, true);
		}
	}

	private function getBilldetailInHTML($param) {
		$bt = $this->customFields['tipo_comprobante'];

		// replace
		$bus = ['$billingType', '$billingLI'];
		$rem = [$bt, $this->getThankYouLI($bt)];
		return str_replace($bus, $rem, file_get_contents($this->path . 'public/template/thank_you.html'));
	}

	private function getThankYouLI(string $bt) {
		if($bt == 'Factura'){
			$r =  'invoice';
			$bus = ['$ruc', '$razonSocial'];
			$rem = [$this->customFields['ruc'], $this->customFields['razon_social']];
		}
		else{
			$r = 'bill';
			$bus = ['$dni'];
			$rem = [$this->customFields['dni']];
		}
		$billingLI = str_replace($bus, $rem, file_get_contents($this->path . 'public/template/template_' . $r . '.html'));

		// replace
		$bus = ['$billingType', '$billingLI'];
		$rem = [$bt, $billingLI];
		echo str_replace($bus, $rem, file_get_contents($this->path . 'public/template/thank_you.html'));
	}

	private function getOrderDetailInAdmin(string $bt) {
		$path = $this->path . 'admin/template/';
		if($bt == 'Boleta'){
			$template = 'bill';
			$bus = ['$dni'];
			$rem = [$this->customFields['dni']];
		}
		else{
			$template = 'invoice';
			$bus = ['$razonSocial', '$ruc'];
			$rem = [$this->customFields['razon_social'], $this->customFields['ruc']];
		}
		$orderP = str_replace($bus, $rem, file_get_contents($path . 'order_' . $template . '.html'));

		// main
		$bus = ['$tipoComprobante', '$orderP'];
		$rem = [$bt, $orderP];
		return str_replace($bus, $rem, file_get_contents($path . 'admin_order_details.html'));
	}
}
