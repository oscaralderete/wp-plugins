<?php
/**
@author: Oscar Alderete wordpress@oscaralderete.com
@website: https://wpe.oscaralderete.com
@editor: 12.1
*/

namespace WebappsParaEmprendedores;

class StateProvinceDistrict {

	private $uri;
	private $path;
	private $templateHiddenInput = '<div><input type="$type" id="$id" name="$id" value="same"></div>';
	private $states = ['CAL' => 'EL CALLAO', 'LMA' => 'MUNICIPALIDAD METROPOLITANA DE LIMA', 'AMA' => 'AMAZONAS', 'ANC' => 'ANCASH', 'APU' => 'APURÍMAC', 'ARE' => 'AREQUIPA', 'AYA' => 'AYACUCHO', 'CAJ' => 'CAJAMARCA', 'CUS' => 'CUSCO', 'HUV' => 'HUANCAVELICA', 'HUC' => 'HUÁNUCO', 'ICA' => 'ICA', 'JUN' => 'JUNÍN', 'LAL' => 'LA LIBERTAD', 'LAM' => 'LAMBAYEQUE', 'LIM' => 'LIMA', 'LOR' => 'LORETO', 'MDD' => 'MADRE DE DIOS', 'MOQ' => 'MOQUEGUA', 'PAS' => 'PASCO', 'PIU' => 'PIURA', 'PUN' => 'PUNO', 'SAM' => 'SAN MARTÍN', 'TAC' => 'TACNA', 'TUM' => 'TUMBES', 'UCA' => 'UCAYALI'];
	private $provinces = ['AMBO' => 'AMBO', 'DOS DE MAYO' => 'DOS DE MAYO'];
	private $districts = ['AMBO' => 'AMBO', 'CAYNA' => 'CAYNA'];
	private $customFieldsKeys = ['province', 'district', 'provinceS', 'districtS'];

	const CODE = 'WPE_StaProDis';
	const SLUG = 'wpe_staprodis';
	const ABREV = 'WPE_WC_SPD_';
	const TITLE = 'Autocompletador de Departamentos, Provincias y Distritos';
	const PERMISSION = 'administrator';
	const ICON = 'dashicons-location';
	const VERSION = '1.0.0';
	const AJAX_ADMIN_LISTENER = '_process_ajax_request';
	const WPE_EMAIL = 'wpe@oscaralderete.com';

	function __construct(string $path) {
		$this->uri = plugin_dir_url($path);
		$this->path = plugin_dir_path($path);

		// update order meta
		add_action('woocommerce_checkout_update_order_meta', [$this, 'update_order_meta'], 10);

		// add custom fields filter
		add_filter('woocommerce_checkout_fields', [$this, 'add_custom_fields']);

		// add hidden input in checkout form
		add_action('woocommerce_after_order_notes', [$this, 'hidden_input_on_checkout'], 10, 1 );

		// add format on admin
		add_filter('woocommerce_localisation_address_formats', [$this, 'add_format_on_admin']);
		add_filter('woocommerce_order_formatted_billing_address' , [$this, 'billing_admin_format_data'], 10, 10);
		add_filter('woocommerce_order_formatted_shipping_address' , [$this, 'shipping_admin_format_data'], 10, 12);
		add_action('woocommerce_formatted_address_replacements', [$this, 'data_after_order_details'], 10, 14);

		// custom styles + JS events
		add_filter('wp_footer', [$this, 'footer_content']);
	}

	// publics
	public function add_custom_fields(array $fields) {
		$fields['billing']['billing_state']['priority'] = 90;

		// province
		$fields['billing'][self::ABREV . 'province'] = [
			'label' => 'Provincia',
			'type' => 'select',
			'required' => true, 
			'class' => array('form-row-wide', 'address-field'),
			'clear' => true,
			'priority' => 92,
			'options' => $this->provinces
		];
		// district
		$fields['billing'][self::ABREV . 'district'] = [
			'label' => 'Distrito',
			'type' => 'select',
			'required' => true, 
			'class' => array('form-row-wide', 'address-field'),
			'clear' => true,
			'priority' => 94,
			'options' => $this->districts
		];

		// shipping inputs
		$fields['shipping']['shipping_state']['priority'] = 90;

		// province
		$fields['shipping'][self::ABREV . 'provinceS'] = [
			'label' => 'Provincia',
			'type' => 'select',
			'required' => true, 
			'class' => array('form-row-wide', 'address-field'),
			'clear' => true,
			'priority' => 92,
			'options' => $this->provinces
		];
		// district
		$fields['shipping'][self::ABREV . 'districtS'] = [
			'label' => 'Distrito',
			'type' => 'select',
			'required' => true, 
			'class' => array('form-row-wide', 'address-field'),
			'clear' => true,
			'priority' => 94,
			'options' => $this->districts
		];


		// remove fields
		$r = [
			'billing' => ['billing_company', 'billing_address_2', 'billing_postcode', 'billing_city'],
			'shipping' => ['shipping_company', 'shipping_address_2', 'shipping_postcode', 'shipping_city']
		];
		foreach($r as $k=>$v){
			foreach($v as $i){
				// e.g. unset($fields['billing']['billing_company']);
				unset($fields[$k][$i]);
			}
		}

		return $fields;
	}

	public function hidden_input_on_checkout($checkout) {
		// Output the hidden link
		echo str_replace(['$type', '$id'], ['hidden', self::ABREV . 'same_address'], $this->templateHiddenInput);
	}

	public function update_order_meta($order_id) {
		// save custom fields
		if(isset($_POST[self::ABREV . 'same_address']) && $_POST[self::ABREV . 'same_address'] == 'same'){
			update_post_meta($order_id, '_' . self::ABREV . 'province', sanitize_text_field($_POST[self::ABREV . 'province']));
			update_post_meta($order_id, '_' . self::ABREV . 'district', sanitize_text_field($_POST[self::ABREV . 'district']));
			update_post_meta($order_id, '_' . self::ABREV . 'provinceS', sanitize_text_field($_POST[self::ABREV . 'province']));
			update_post_meta($order_id, '_' . self::ABREV . 'districtS', sanitize_text_field($_POST[self::ABREV . 'district']));
		}
		else{
			foreach($this->customFieldsKeys as $i){
				if(!empty($_POST[self::ABREV . $i])){
					update_post_meta($order_id, '_' . self::ABREV . $i, sanitize_text_field($_POST[self::ABREV . $i]));
				}
			}
		}
	}

	public function add_format_on_admin($formats) {
		//to escape # from order id 
		$formats['PE'] = "{name}\n{company}\n{address_2}\n{address_1}\n{city} {postcode}\n{country} {custom_address}";
		
		return $formats;
	}
	
	public function billing_admin_format_data($address, $order){
		//echo '<pre>';var_dump($order);echo '</pre>';
		$address['custom_address'] = $this->states[$order->get_billing_state()] . ', ' . get_post_meta($order->get_id(), '_' . self::ABREV . 'province', true) . ', ' . get_post_meta($order->get_id(), '_' . self::ABREV . 'district', true);

		return $address;
	}

	public function shipping_admin_format_data($address, $order){
		$address['custom_address'] = $this->states[$order->get_shipping_state()] . ', ' . get_post_meta($order->get_id(), '_' . self::ABREV . 'provinceS', true) . ', ' . get_post_meta($order->get_id(), '_' . self::ABREV . 'districtS', true);

		return $address;
	}

	public function data_after_order_details($fields, $args){
		$fields['{custom_address}'] = $args['custom_address'];

		return $fields;
	}

	public function footer_content() {
		// only on checkout page
		if(!is_checkout() && !is_wc_endpoint_url()){
			return;
		}

		$bus = ['$spd', '$jsFileUrl', '$cssFileUrl'];
		$rem = [$this->getSPD(true), $this->uri . 'public/js/scripts.js?v=' . self::VERSION, $this->uri . 'public/css/styles.css?v=' . self::VERSION];
		echo str_replace($bus, $rem, file_get_contents($this->path . 'public/template/footer.html'));
	}

	// privates
	private function getSPD(bool $asString) {
		return file_get_contents($this->path . '/includes/spd.json');
	}
}
