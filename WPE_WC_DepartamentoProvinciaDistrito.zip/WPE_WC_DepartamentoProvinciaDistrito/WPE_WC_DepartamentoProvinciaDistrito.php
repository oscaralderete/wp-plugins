<?php
/**
Plugin Name: Departamentos, Provincias y Distritos
Plugin URI: https://wpe.oscaralderete.com
Description: Este plugin está hecho específicamente para WooCommerce. Le agrega al formulario del checkout de WooCommerce unos selectores de provincia y distrito cuyo contenido es automáticamente rellenado y que hacen más sencillo y rápido el proceso de compra. Al estar hecho específicamente para comercios del Perú, esta plugin remueve algunos campos que no suelen usarse como código postal y otros.
Version: 1.0.0
Author: WPE - Oscar Alderete <wordpress@oscaralderete.com>
Author URI: wordpress@oscaralderete.com
License: GPL v2 or later
 */
if(!defined('WPINC')){
	die;
}

// load only if WooCommerce is active
if(in_array('woocommerce/woocommerce.php', apply_filters('active_plugins', get_option('active_plugins')))){
	require plugin_dir_path(__FILE__) . 'includes/StateProvinceDistrict.php';

	new \WebappsParaEmprendedores\StateProvinceDistrict(__FILE__);
}